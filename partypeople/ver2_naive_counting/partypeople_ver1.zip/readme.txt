compile
gcc -o p partypeople.c

execute
./p input.txt
